 prerequisite: ubuntu 18+
 
- run the following command to setup 3node k3d cluster
```
git clone https://github.com/asrikanth29/k8s
sudo chmod +x ./k8s/k3d/install.sh
./k8s/k3d/install.sh
```
