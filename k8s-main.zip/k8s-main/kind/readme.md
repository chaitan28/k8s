## Prerequisites *Set up Ubuntu server and run the following commands for the cluster creation*
- run the following command to setup 1 worker 2node setup, if you want to coustomise, change config.yml in repo
```
sudo git clone https://github.com/asrikanth29/k8s && cd k8s/kind && sudo chmod +x install.sh config.yaml && sudo ./install.sh
```
